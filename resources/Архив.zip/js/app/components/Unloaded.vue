<template lang="html">
  <h2>Loading...</h2>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
